# Life Planner — local-first PWA

A responsive, installable Progressive Web App starter for personal daily planning. It has no account, no server, no analytics and no third-party JavaScript dependencies. User content is stored in the browser's local storage for the current site origin.

## Features included

- Today dashboard with date, task summary, task list and morning/evening routines
- Add, complete, delete and filter tasks; optional due date and time
- Weekly and monthly recurring tasks in both list and monthly calendar views; completion is tracked per occurrence
- Weekly and monthly recurring tasks in both list and monthly calendar views; completion is tracked per occurrence
- Habit checklist with add/remove and daily completion tracking
- Wellbeing mood check-in and a short breathing pause
- Journal editor with date-based entries and prompt suggestions
- Career & learning notes and tasks
- Goals with progress tracking
- Home & errands list
- Fitness & nutrition notes and tasks
- Travel ideas list
- JSON export/import backup
- Responsive layout, web app manifest, app icons and offline app-shell cache

## Important privacy and storage notes

- No account or cloud sync. iPhone and desktop have separate local data stores.
- Clearing website data, deleting the installed app/browser data, or changing the site's domain/path may make saved data unavailable. Export a JSON backup regularly from **Settings & backup**.
- The service worker caches the app shell for offline opening after the app has been loaded once online. This does not make the app's data sync across devices.
- The app has not been deployed to a public URL by this project bundle. You must publish it to an HTTPS static host before installing it on your phone.

## Run locally

A PWA service worker requires HTTPS or localhost. Do not open `index.html` directly using a `file://` URL.

With Python installed, from this folder run:

```bash
python3 -m http.server 8000
```

Then open `http://localhost:8000` in a browser on that computer. This is for local testing only.

## Publish with GitHub Pages

1. Create a GitHub repository, for example `life-planner`.
2. Upload the **contents** of this folder (`index.html`, `styles.css`, `app.js`, `manifest.json`, `sw.js`, `icons/`, `README.md`) to the repository's root.
3. In the repository, open **Settings → Pages**.
4. Under build/deployment, choose **Deploy from a branch**, select the `main` branch and `/ (root)`, then save.
5. Wait for GitHub Pages to publish the site. Open the HTTPS URL shown in the Pages settings and test it on desktop first.
6. If the repository is named `life-planner`, the URL will usually resemble `https://YOUR-USERNAME.github.io/life-planner/`. Use the exact URL GitHub shows; do not guess it.
7. Open the published URL on iPhone in Safari, tap **Share**, choose **Add to Home Screen**, optionally enable **Open as Web App** if shown, then tap **Add**.
8. On desktop, open the published URL in Chrome or Edge and use the install icon/menu if available. On macOS, Safari can offer **Add to Dock** on supported versions.

## Updating after publishing

Commit/upload updated files to the same repository. Wait for Pages to finish deploying, then reopen the app while online. If a service-worker update looks stale, close the app and reopen it after a short wait. Cache name is `life-planner-v1` in `sw.js`; change it when you make a release that needs a fresh cache.

## Quick validation checklist

- Add a task, refresh, and confirm it remains.
- Check off a habit, refresh, and confirm it remains checked for today.
- Add a journal entry and export a backup.
- Import the backup into a clean browser profile only if you intend to replace that profile's Life Planner data.
- Test the published app once online, then switch the device to airplane mode and reopen it.

## Known limitations in this starter

- No login, cloud sync, shared data, push notifications or native App Store listing.
- Habits track the current day only; no historical analytics/streak calendar yet.
- Routines are built-in checklists; editing routine items is not yet exposed in the UI.
- Mood check-ins are saved by date, but there is no long-term chart.
- Travel planning is a simple idea list, not a booking/calendar integration.
