# Life Planner — Kurulum ve yayınlama rehberi

Bu klasör, Life Planner'ın ilk kullanılabilir PWA sürümüdür. Uygulama hesabı veya sunucu veritabanı yoktur; veriler kullandığın tarayıcıda/cihazda saklanır.

## Bu sürümde çalışan özellikler

- Günlük görünüm, görev ekleme/tamamlama/silme, tarih ve saat, kategori ve arama/filtreleme
- Sabah ve akşam rutinlerini işaretleme
- Günlük alışkanlık listesi oluşturma ve takip etme
- Duygu durumunu günlük kaydetme ve kısa nefes molası
- Tarihli günlük yazıları ve yazma önerileri
- Kariyer/öğrenme notları ve görevleri
- Hedef ekleme ve yüzde bazlı ilerleme
- Ev/iş listesi ve seyahat fikirleri
- JSON yedek dışa aktarma ve yedekten içe aktarma
- Mobil uyumlu tasarım, uygulama manifestosu, ikonlar ve çevrimdışı uygulama kabuğu önbelleği

## Henüz olmayanlar

- Herkese açık yayınlanmış bir URL
- iPhone'a yüklenmiş uygulama (bu işlemi senin cihazında yapmam gerekiyor değil; aşağıdaki adımları sen uygulayacaksın)
- Cihazlar arasında senkronizasyon, hesap, bulut yedeği
- Bildirimler, App Store sürümü, gelişmiş alışkanlık geçmişi/serileri ve grafikler
- Rutin maddelerini arayüzden düzenleme

## Yayınlamadan önce önemli bilgi

GitHub Pages'e yayınladığında uygulamanın **kod dosyaları** web'de erişilebilir olur. Günlüklerin, görevlerin ve kişisel notların bu dosyalara yazılmaz; bunlar tarayıcının yerel saklama alanında kalır. Yine de uygulama dosyalarına özel bilgi koyma. Verilerini düzenli olarak **Settings & backup → Export JSON** ile yedekle.

## En kolay yayınlama: GitHub Pages

1. [GitHub](https://github.com/) hesabına giriş yap veya hesap oluştur.
2. Yeni bir repository oluştur. Örneğin adı `life-planner` olsun.
3. Bu ZIP dosyasını bilgisayarında aç.
4. ZIP içindeki klasörün kendisini değil, **klasörün içindeki dosya ve `icons` klasörünü** repository'nin köküne yükle. Kök dizinde `index.html`, `app.js`, `styles.css`, `manifest.json`, `sw.js` ve `icons/` görünmeli.
5. Repository içinde **Settings → Pages** bölümüne git.
6. **Build and deployment** altında **Deploy from a branch** seç.
7. Branch olarak `main`, klasör olarak `/(root)` seç ve **Save** de.
8. GitHub Pages yayını hazırladığında aynı Pages ekranında sana kesin web adresini gösterir. Genellikle `https://KULLANICI-ADIN.github.io/life-planner/` biçimindedir ama **GitHub'ın verdiği gerçek adresi kullan**.
9. Siteyi önce bilgisayarda açıp görev ekleme ve yedekleme gibi özellikleri dene. Sonra iPhone'da Safari ile aynı HTTPS adresini aç.

Resmî yönerge: [GitHub Pages yayın kaynağını ayarlama](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site).

## iPhone ana ekranına ekleme

1. Yayınlanmış HTTPS adresini **Safari** ile aç.
2. Paylaş düğmesine dokun.
3. **Add to Home Screen / Ana Ekrana Ekle** seçeneğini seç.
4. Varsa **Open as Web App / Web Uygulaması Olarak Aç** seçeneğini etkinleştir.
5. **Add / Ekle** düğmesine dokun.
6. Ana ekrandaki Life Planner simgesine dokunarak aç. PWA kurulumu için yayın adresi HTTPS olmalı; `index.html` dosyasını doğrudan açmak yeterli değildir.

## Bilgisayarda kullanma

- Chrome veya Edge'de yayınlanan adresi aç; tarayıcı menüsünde **Install Life Planner** veya **Install page as app** seçeneği görünüyorsa onu kullan.
- macOS'ta desteklenen Safari sürümlerinde siteyi Dock'a ekleme seçeneği bulunabilir.
- Aynı siteyi normal tarayıcı sekmesinde kullanmak da mümkün.

## Veriler ve yedekleme

- iPhone Safari verileri ile masaüstü tarayıcı verileri birbirinden ayrıdır; otomatik eşitlenmez.
- Tarayıcı/site verilerini temizlemek kayıtları silebilir.
- Yedek almak için **Settings & backup → Export JSON** kullan.
- Yedek geri yüklemek için **Import a backup** seç. İçe aktarma, o tarayıcıdaki mevcut Life Planner verisinin yerine geçer.
- Yedek dosyasını güvenli bir yerde sakla; içinde günlük notların bulunabilir.

## İlk kontrol listesi

- [ ] Bir görev ekle, sayfayı yenile ve görevin durduğunu doğrula.
- [ ] Bir alışkanlığı işaretle, yenile ve işaretin kaldığını doğrula.
- [ ] Günlük yazısı kaydet.
- [ ] JSON yedeği indir.
- [ ] Yayınlanan siteyi bir kez çevrimiçi açtıktan sonra çevrimdışı açılmayı dene.
- [ ] iPhone ve bilgisayardaki verilerin ayrı olduğunu unutma.


## Yeni özellik: haftalık ve aylık yapılacaklar

Uygulamada **Weekly & monthly** bölümü eklendi. Buradan haftanın belirli bir gününe veya ayın belirli bir gününe tekrarlanan görev ekleyebilirsin. Görevleri liste veya aylık takvim görünümünde görebilir, her gerçekleşmeyi ayrı ayrı tamamlandı olarak işaretleyebilir ve aylar arasında gezebilirsin. Yeni sürümü yayınlarken ZIP içindeki tüm dosyaları eskilerinin üzerine yükle; `sw.js` önbellek sürümü güncellendi.
